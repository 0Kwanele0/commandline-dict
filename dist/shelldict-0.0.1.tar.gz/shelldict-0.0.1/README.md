shelldict
======

A simple commandline dictionary.
Use it to easily get definations and meanings of english words.

The code is written in Python 3.

Installation
------------

Fast install:


    pip install shelldict

For a manual install get this package:

    git clone https://github.com/coderkwan/shelldict.git
    cd shelldict

Install the package:

    python setup.py install    


Usage
------

      shelldict any_english_word

Enjoy!!!
